Josh Chapman, Melissa Alexander, Jack Zimmerman

Meeting for the first time about two weeks ago, we determined that we would prefer to do the prompted final project rather than come up with
our own. We decided it would be best to divide the work to be done in sections that would allow us to work asynchronously during the
busy finals period. Josh handled the organization of the files/the django coding, Melissa handled the bootstrap/html within the files, and Jack
handled the styling of the site through CSS and some bootstrap classes.

We have no packages outside of what has been used in previous django projects, but would like to remind the user to create their own user.
Without your own user, you will not be able to access the site. 
Additionally, as a user you will be unable to edit or delete posts that youdo not own. Create your own categories and todos first, so that you 
may test the functionality of our edit and delete features for each.