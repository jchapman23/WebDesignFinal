#Josh Chapman, Melissa Alexander, Jack Zimmerman
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import models
from django.forms import ModelForm
from django.urls import reverse


class Category(models.Model):
    name = models.TextField()
    owner = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
    )

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('category_detail', args=[str(self.id)])

class ToDo(models.Model):
    title = models.TextField()
    priority = models.BooleanField()
    completed = models.BooleanField()
    category = models.ForeignKey(
        Category, 
        related_name = 'todos',
        on_delete=models.CASCADE
    )
    owner = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
    )
    
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('todo_detail', args=[str(self.id)])

class CategoryForm(ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'owner',]

class ToDoForm(ModelForm):
    class Meta:
        model = ToDo
        fields = ['title', 'owner', 'category', 'priority', 'completed',]