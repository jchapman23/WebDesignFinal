#Josh Chapman, Melissa Alexander, Jack Zimmerman
from django.contrib import admin
from .models import Category, ToDo

class ToDoInline(admin.StackedInline): # new
    model = ToDo
    extra = 1

class CategoryAdmin(admin.ModelAdmin): # new
    inlines = [
        ToDoInline,
        ]

admin.site.register(Category, CategoryAdmin)
admin.site.register(ToDo)