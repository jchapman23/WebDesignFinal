#Josh Chapman, Melissa Alexander, Jack Zimmerman
from django.urls import path
from .views import (
    CategoryListView,
    CategoryUpdateView, # new
    CategoryDetailView, # new
    CategoryDeleteView, # new
    CategoryCreateView, # new
    ToDoListView,   # new
    ToDoUpdateView, # new
    ToDoDetailView, # new
    ToDoDeleteView, # new
    ToDoCreateView, # old
    ToDoCompleteView,
)

urlpatterns = [
    path('<int:pk>/edit/',
         CategoryUpdateView.as_view(), name='category_edit'), # new
    path('<int:pk>/',
         CategoryDetailView.as_view(), name='category_detail'), # new
    path('<int:pk>/delete/',
         CategoryDeleteView.as_view(), name='category_delete'), # new
    path('new/', CategoryCreateView.as_view(), name='category_new'), # new
    path('', CategoryListView.as_view(), name='category_list'),
    path('todo/<int:pk>/edit/',
         ToDoUpdateView.as_view(), name='todo_edit'), # new
    path('todo/<int:pk>/',
         ToDoDetailView.as_view(), name='todo_detail'), # new
    path('todo/<int:pk>/delete/',
         ToDoDeleteView.as_view(), name='todo_delete'), # new
    path('todo/new/', ToDoCreateView.as_view(), name='todo_new'), # new
    path('todo/', ToDoListView.as_view(), name='todo_list'),
    path('todo/complete/', ToDoCompleteView.as_view(), name='todo_complete')
]