#Josh Chapman, Melissa Alexander, Jack Zimmerman
from django.apps import AppConfig


class CategoriesConfig(AppConfig):
    name = 'categories'
