#Josh Chapman, Melissa Alexander, Jack Zimmerman
from django.views.generic import ListView, DetailView # new
from django.views.generic.edit import UpdateView, DeleteView, CreateView # new
from django.urls import reverse_lazy # new
from .models import Category, ToDo

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import redirect


class CategoryListView(ListView):
    model = Category
    template_name = 'category_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['info'] = "This is the list of category objects in the DB"
        context['todos'] = ToDo.objects.all()
        return context

class CategoryDetailView(DetailView): # new
    model = Category
    template_name = 'category_detail.html'


class CategoryUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView): # new
    model = Category
    fields = ('name',)
    template_name = 'category_edit.html'
    login_url = 'login'

    def test_func(self):
        category = self.get_object()
        return category.owner == self.request.user

    def handle_no_permission(self):
        return redirect('category_list')



class CategoryDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView): # new
    model = Category
    template_name = 'category_delete.html'
    success_url = reverse_lazy('category_list')
    login_url = 'login'

    def test_func(self):
        category = self.get_object()
        return category.owner == self.request.user

    def handle_no_permission(self):
        return redirect('category_list')


class CategoryCreateView(LoginRequiredMixin, CreateView): # new
    model = Category
    template_name = 'category_new.html'
    fields = ('name',)
    login_url = 'login'

    def form_valid(self,form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class ToDoListView(ListView):
    model = ToDo
    template_name = 'todo_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['info'] = "This is the list of ToDo objects in the DB"
        context['key'] = "Priority ToDos are uppercased, and Completed ToDos are crossed out"
        return context

class ToDoCompleteView(ListView):
    model = ToDo
    template_name = 'todo_complete.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['info'] = "This is the list of completed ToDo objects in the DB"
        return context

class ToDoDetailView(DetailView): # new
    model = ToDo
    template_name = 'todo_detail.html'


class ToDoUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView): # new
    model = ToDo
    fields = ('title', 'priority', 'completed')
    template_name = 'todo_edit.html'
    login_url = 'login'

    def test_func(self):
        todo = self.get_object()
        return todo.owner == self.request.user

    def handle_no_permission(self):
        return redirect('todo_list')



class ToDoDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView): # new
    model = ToDo
    template_name = 'todo_delete.html'
    success_url = reverse_lazy('todo_list')
    login_url = 'login'

    def test_func(self):
        todo = self.get_object()
        return todo.owner == self.request.user

    def handle_no_permission(self):
        return redirect('todo_list')


class ToDoCreateView(LoginRequiredMixin, CreateView): # new
    model = ToDo
    template_name = 'todo_new.html'
    fields = ('title', 'priority', 'completed', 'category')
    login_url = 'login'

    def form_valid(self,form):
        form.instance.owner = self.request.user
        return super().form_valid(form)